package automation.screenshots;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
//import org.apache.commons.io.FileUtils;

//public class Takescreenshots {
//
//    public static void takeScreenshot (WebDriver lea_page, HashMap<String, String> sys_default_props, String curr_page) {
//        File scrFile = ((TakesScreenshot) lea_page).getScreenshotAs(OutputType.FILE);
//        String fileName = sys_default_props.get("screenshotOutputFolder") + "\\screenshot-"+curr_page+".png";
//        File outputFile = new File(fileName);
//        try {
//            FileUtils.copyFile(scrFile, outputFile);
//        } catch (IOException ie) {
//            ie.printStackTrace();
//        }
//    }
//}
