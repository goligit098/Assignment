/**
 * @author jagdeepjain
 *
 */
package automation.config;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Browser {
     WebDriver driver;
    private String toolsQAUrl = "https://demoqa.com/";

        public Browser(WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver setBrowser() {
        System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/drivers/chromedriver.exe");
        DesiredCapabilities desiredCapabilities = DesiredCapabilities.chrome();
        final ChromeOptions chromeOptions = new ChromeOptions();
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();

        return driver;
    }
    
    // return the driver with fire fox instance
    public WebDriver getBrowser() {
        return setBrowser();
    }
    
    // launch URL with the driver instance
    public void openURL(String append) {
        driver.manage().window().maximize();
        driver.get(toolsQAUrl+append);
    }

}
